﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StockManagementSystem
{
    public partial class SearchAndViewItems : Form
    {
        static string connectString = @"server=DESKTOP-83QIQD0\SQLEXPRESS; database=StockManagement; integrated security=true";

        SqlConnection con = new SqlConnection(connectString);
        public SearchAndViewItems()
        {
            InitializeComponent();
        }

        private void SearchAndViewItems_Load(object sender, EventArgs e)
        {
            CategoryComboBox();
            companyComboBox1();
        }
        private void companyComboBox1()
        {
            string query = "select Id, Name from Companies";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            con.Open();
            DataSet ds = new DataSet();
            da.Fill(ds, "Companies");
            companyComboBox.DisplayMember = "Name";
            companyComboBox.ValueMember = "Id";
            companyComboBox.DataSource = ds.Tables["Companies"];
            con.Close();
        }

        private void CategoryComboBox()
        {
            string query = "select Id, Name from Categories";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            con.Open();
            DataSet ds = new DataSet();
            da.Fill(ds, "Categories");
            categoryComboBox.DisplayMember = "Name";
            categoryComboBox.ValueMember = "Id";
            categoryComboBox.DataSource = ds.Tables["Categories"];
            con.Close();
        }
    }
}

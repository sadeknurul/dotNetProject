﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StockManagementInfoApp;

namespace StockManagementInfoApp.Models
{
    public class Person
    {
        public int Id { get; set; }
        public string CategoryName { get; set; }
        public string CompanyName { get; set; }
    }
}
